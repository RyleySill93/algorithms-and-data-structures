require_relative 'graph'

# O(|V|**2 + |E|).
def dijkstra1(source)
end
